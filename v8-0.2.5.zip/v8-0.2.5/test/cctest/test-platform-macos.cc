// Copyright 2006-2008 Google, Inc. All Rights Reserved.
//
// Tests of the TokenLock class from lock.h

#include <stdlib.h>

#include "v8.h"
#include "cctest.h"

using namespace ::v8::internal;
